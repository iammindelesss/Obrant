// Mobile menu toggle for pages other than the calculator (which has its own in script.js).
(function () {
  var btn = document.getElementById('menuBtn'), nav = document.getElementById('nav');
  if (!btn || !nav) return;
  btn.addEventListener('click', function () {
    btn.setAttribute('aria-expanded', String(nav.classList.toggle('open')));
  });
})();
