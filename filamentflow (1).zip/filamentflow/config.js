// Backend settings. Leave empty until you have created a Supabase project (see SETUP.md).
// The anon (public) key is designed to be visible in the browser. NEVER put a service_role key here.
window.FF_CONFIG = { SUPABASE_URL: '', SUPABASE_ANON_KEY: '' };
