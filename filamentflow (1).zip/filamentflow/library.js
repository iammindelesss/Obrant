/* Model Library (demo). MODELS is sample data; later this list comes from the backend (see SETUP.md).
 * To show a real free download, put the file in a models/ folder and set file: 'models/name.stl'. */
const MODELS = [
  { id: 'cable-clip', title: 'Desk cable clip', creator: 'Sample Creator', category: 'Home & Desk', tags: ['organiser', 'clip', 'cable'], premium: false, added: '2026-09-28', formats: ['STL', '3MF'], license: 'CC BY 4.0', file: null,
    desc: 'A small clip that holds charging cables to the edge of a desk.', tips: '0.2 mm layers, 3 walls, 15% infill, no supports.' },
  { id: 'phone-stand', title: 'Folding phone stand', creator: 'Sample Creator', category: 'Home & Desk', tags: ['phone', 'stand'], premium: false, added: '2026-09-12', formats: ['STL'], license: 'CC BY-NC 4.0', file: null,
    desc: 'A two-part phone stand that folds flat for travel.', tips: '0.2 mm layers, 4 walls, 20% infill. Print flat.' },
  { id: 'gear-set', title: 'Modular gear set', creator: 'Demo Workshop', category: 'Mechanical', tags: ['gears', 'mechanical', 'education'], premium: true, added: '2026-10-05', formats: ['STL', '3MF', 'OBJ'], license: 'Commercial licence (demo)', file: null,
    desc: 'Interlocking gears of several sizes for teaching and prototypes.', tips: '0.15 mm layers, 5 walls, 40% infill, PETG recommended.' },
  { id: 'plant-pot', title: 'Geometric plant pot', creator: 'Demo Workshop', category: 'Decor', tags: ['planter', 'vase', 'decor'], premium: false, added: '2026-08-30', formats: ['STL', 'OBJ'], license: 'CC BY 4.0', file: null,
    desc: 'A faceted pot with a drainage tray.', tips: '0.2 mm layers, vase mode for the pot, 3 walls for the tray.' },
  { id: 'dice-tower', title: 'Tabletop dice tower', creator: 'Sample Creator', category: 'Games', tags: ['tabletop', 'dice', 'game'], premium: true, added: '2026-10-14', formats: ['3MF'], license: 'Personal use (demo)', file: null,
    desc: 'A folding dice tower with an internal baffle ramp.', tips: '0.2 mm layers, 3 walls, 10% infill, supports under the top bridge.' },
  { id: 'hex-organiser', title: 'Hex drawer organiser', creator: 'Demo Workshop', category: 'Home & Desk', tags: ['organiser', 'hex', 'storage'], premium: false, added: '2026-07-19', formats: ['STL', '3MF'], license: 'CC0', file: null,
    desc: 'Tessellating hex bins that fill a drawer with no wasted space.', tips: '0.2 mm layers, 2 walls, 10% infill.' }
];

const $ = (id) => document.getElementById(id);
const state = { q: '', cat: 'all', sort: 'newest' };

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}
function matches(m) {
  const hay = [m.title, m.desc, m.tags.join(' ')].join(' ').toLowerCase();
  const q = state.q.trim().toLowerCase();
  return (state.cat === 'all' || m.category === state.cat) && (!q || hay.includes(q));
}
function sorted(list) {
  const s = list.slice();
  if (state.sort === 'newest') s.sort((a, b) => b.added.localeCompare(a.added));
  if (state.sort === 'free') s.sort((a, b) => Number(a.premium) - Number(b.premium));
  if (state.sort === 'premium') s.sort((a, b) => Number(b.premium) - Number(a.premium));
  return s;
}
const priceLabel = (m) => (m.premium ? 'Premium (demo)' : 'Free');

function renderList() {
  const list = sorted(MODELS.filter(matches));
  const grid = $('grid');
  grid.innerHTML = '';
  list.forEach((m) => {
    const a = el('a', 'model-card');
    a.href = '#model-' + m.id;
    a.appendChild(el('div', 'thumb', 'No preview image'));
    const body = el('div', 'body');
    body.appendChild(el('h3', '', m.title));
    body.appendChild(el('p', 'meta', m.creator + ' · ' + priceLabel(m)));
    const tags = el('div', 'tags');
    m.tags.forEach((t) => tags.appendChild(el('span', 'tag', t)));
    body.appendChild(tags);
    a.appendChild(body);
    grid.appendChild(a);
  });
  $('count').textContent = list.length + (list.length === 1 ? ' model' : ' models');
  $('empty').hidden = list.length > 0;
}

function renderDetail(m) {
  const v = $('detailView');
  v.innerHTML = '';
  const back = el('a', 'back', '← All models');
  back.href = '#';
  v.appendChild(back);
  v.appendChild(el('h2', '', m.title));
  const wrap = el('div', 'detail');
  wrap.appendChild(el('div', 'thumb', 'No preview image (demo listing)'));
  const dl = el('dl');
  [['Creator', m.creator], ['Price', priceLabel(m)], ['Category', m.category], ['File formats', m.formats.join(', ')],
   ['Licence', m.license], ['Printing recommendations', m.tips], ['Description', m.desc]].forEach((row) => {
    dl.appendChild(el('dt', '', row[0]));
    dl.appendChild(el('dd', '', row[1]));
  });
  const side = el('div');
  side.appendChild(dl);
  if (!m.premium && m.file) {
    const dlink = el('a', 'btn primary', 'Download');
    dlink.href = m.file;
    dlink.setAttribute('download', '');
    side.appendChild(dlink);
  } else {
    const b = el('button', 'btn primary', m.premium ? 'Purchase unavailable' : 'No file in this demo');
    b.disabled = true;
    side.appendChild(b);
    side.appendChild(el('p', 'note-box', m.premium
      ? 'Demo listing. Checkout and secure file delivery are not built yet, so nothing can be bought.'
      : 'Demo listing with no real file attached.'));
  }
  const rep = el('button', 'btn', 'Report this model (needs backend)');
  rep.disabled = true;
  rep.style.marginTop = '12px';
  side.appendChild(rep);
  wrap.appendChild(side);
  v.appendChild(wrap);
}

function route() {
  const id = location.hash.indexOf('#model-') === 0 ? location.hash.slice(7) : null;
  const m = MODELS.find((x) => x.id === id);
  $('listView').hidden = Boolean(m);
  $('detailView').hidden = !m;
  if (m) { renderDetail(m); window.scrollTo(0, 0); }
}

(function init() {
  Array.from(new Set(MODELS.map((m) => m.category))).sort().forEach((c) => {
    const o = el('option', '', c); o.value = c; $('cat').appendChild(o);
  });
  $('q').addEventListener('input', (e) => { state.q = e.target.value; renderList(); });
  $('cat').addEventListener('change', (e) => { state.cat = e.target.value; renderList(); });
  $('sort').addEventListener('change', (e) => { state.sort = e.target.value; renderList(); });
  window.addEventListener('hashchange', route);
  renderList();
  route();
})();
